Description:
Given Buggy rating is a web application is un identifiable framework for developing [maybe mix of all like react, angular js, html5, etc] - challenging for identifying objects and automating the workflows.

Main functionalities are below:

Registration
Login
View the ratings [number of votes] - popular cars
Vote for cars [Vote only one time for a car ]
Logout


Approach:

A choice of tools and frameworks and language are available and - I have chosen Cypress for writing automation scripts for this web application, with GitHub repository.

There is plenty of automation possible from this application but given time constraint i have only automated few functionalities.

Found following bugs:

Elements are not easy to identify - Consistency required ex: id of an element

Duplication of element declaration

Non repeatability of Register and Vote functionality

Registration page and success message still displayed after login/registration completed/logout

Profile section still remained post logout

Pagination issue



Automating all possible scenarios - namely 5 here